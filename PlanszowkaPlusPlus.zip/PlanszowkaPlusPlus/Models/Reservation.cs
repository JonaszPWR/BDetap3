using System.ComponentModel.DataAnnotations.Schema;

namespace PlanszowkaPlusPlus.Models
{
    public class Reservation
    {
        public int Id { get; set; }
        public DateTime ReservationDate { get; set; }
        public TimeOnly TimeStart { get; set; }
        public TimeOnly TimeEnd { get; set; }

        [ForeignKey("GameTable")]
        public int TableId { get; set; }
        [ForeignKey("Member")]
        public int MemberId { get; set; }
        //relation properties
        public GameTable GameTable { get; set; }
        public Member Member { get; set; }
    }
}